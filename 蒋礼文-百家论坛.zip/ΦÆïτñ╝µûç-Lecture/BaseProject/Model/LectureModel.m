//
//  LectureModel.m
//  BaseProject
//
//  Created by apple-jd01 on 15/11/4.
//  Copyright © 2015年 guaiguai. All rights reserved.
//

#import "LectureModel.h"

@implementation LectureModel


+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [LectureListModel class]};
}
@end
@implementation LectureListModel

@end


