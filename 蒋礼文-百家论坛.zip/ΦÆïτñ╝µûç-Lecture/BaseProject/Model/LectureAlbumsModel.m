//
//  LectureAlbumsModel.m
//  百家讲坛合集
//
//  Created by apple-jd01 on 15/11/5.
//  Copyright © 2015年 guaiguai. All rights reserved.
//

#import "LectureAlbumsModel.h"

@implementation LectureAlbumsModel

@end
@implementation LectureAlbummodel

@end


@implementation LectureAlbumsTracksModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [LectureAlbumsTracksListModel class]};
}

@end


@implementation LectureAlbumsTracksListModel

@end


