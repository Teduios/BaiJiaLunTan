//
//  TabBarController.m
//  BaseProject
//
//  Created by apple-jd01 on 15/11/18.
//  Copyright © 2015年 guaiguai. All rights reserved.
//

#import "TabBarController.h"

@interface TabBarController ()

@end

@implementation TabBarController

+ (void)initialize{
    if (self == [TabBarController class]) {
        UITabBar *tabBar = [UITabBar appearance];
        [tabBar setBackgroundImage:[UIImage imageNamed:@"tabbarBkg"]];
        [tabBar setSelectedImageTintColor:[UIColor orangeColor]];
        UITabBarItem *barItem = [UITabBarItem appearance];
        [barItem setTitlePositionAdjustment:UIOffsetMake(0, -2)];
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        dict[NSForegroundColorAttributeName] = [UIColor orangeColor];
        [barItem setTitleTextAttributes:dict forState:UIControlStateSelected];
    }
   
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
