//
//  LectureTracksViewController.m
//  BaseProject
//
//  Created by apple-jd01 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LectureTracksViewController.h"
#import "LectureTracksViewModel.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import "UMSocial.h"
//#import <AFURLSessionManager.h>
static NSInteger i = 0;

@interface LectureTracksViewController ()
@property(nonatomic,strong)LectureTracksViewModel *tracksVM;
/** AVPlayer实现播放*/
@property(nonatomic,strong)AVPlayer *player;
/** 播放按钮 */
@property (weak, nonatomic) IBOutlet UIButton *playBtn;
/** 当前播放 */
@property(nonatomic)NSInteger currentPlay;
/** 开始播放时间 */
@property(nonatomic)NSTimeInterval time;
/** 定时器 */
@property(nonatomic,strong)NSTimer *timer;
/** 标题 */
@property (weak, nonatomic) IBOutlet UILabel *titleLb;
/** 图片 */
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
/** 滑动条 */
@property (weak, nonatomic) IBOutlet UISlider *slider;
/** 开始时长 */
@property (weak, nonatomic) IBOutlet UILabel *beginTimeLb;
/** 总时长 */
@property (weak, nonatomic) IBOutlet UILabel *overTimeLb;


@end

@implementation LectureTracksViewController


- (LectureTracksViewModel *)tracksVM {
    if(_tracksVM == nil) {
        _tracksVM = [[LectureTracksViewModel alloc] initWithTracksId:_tracksId];
    }
    return _tracksVM;
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.player pause];
    [self runTimer];
    [_timer invalidate];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"书说";
    [Factory addBackItemToVC:self];
     _currentPlay = _beginPlay;
    [self playBook];
        i = 0;
     [self runTimer];
    [self.player play];
}
/** 开启一个定时器，记录播放时间 */
- (void)runTimer{
    _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(playTimes) userInfo:nil repeats:YES];
}

- (void)playTimes{
    i = i + 1;
/** 播放时长 */
    if (i < 60) {
         self.beginTimeLb.text = [NSString stringWithFormat:@"00:%02ld",i];
    }else{
        self.beginTimeLb.text = [NSString stringWithFormat:@"%02ld:%02ld",i/60,i % 60];
    }
/** 播放总时长 */
    NSMutableArray *durationArray = [NSMutableArray new];
    for (int i = 0; i < _albumsArr.count; i++) {
        LectureAlbumsTracksListModel *model = _albumsArr[i];
        [durationArray addObject:model.duration];
    }
    NSArray *durationArr = [durationArray copy];
    NSNumber *num = durationArr[_currentPlay];
    NSInteger duration = num.integerValue;
/** 播放完自动下一曲 */
    if (i == duration) {
        i = 0;
        self.playBtn.selected = NO;
        if (_currentPlay < _albumsArr.count) {
            _currentPlay += 1;
        }
        if (_currentPlay == _albumsArr.count) {
            _currentPlay = 0;
        }
        [self playBook];
        [self.player play];
    }
/** 总时长标签 */
    self.overTimeLb.text = [NSString stringWithFormat:@"%02ld:%02ld",num.integerValue / 60,num.integerValue % 60];
/** slider实时改变 */
    self.slider.value =1.0 - (num.floatValue - i)/num.floatValue;

}
/** 暂停 && 播放 */
- (IBAction)play:(id)sender {
    if (self.playBtn.selected == YES) {
        [self.player play];
        [self runTimer];
    }else{
        [self.player pause];
        [_timer invalidate];
        }
    self.playBtn.selected = !self.playBtn.selected;
}
/** 下一曲 */
- (IBAction)nextBook:(id)sender {
    i = 0;
    [self runTimer];
    self.playBtn.selected = NO;
    if (_currentPlay < _albumsArr.count) {
       _currentPlay += 1;
        self.currentPlay = _currentPlay;
    }
    if (_currentPlay == _albumsArr.count) {
        _currentPlay = 0;
    }
    [self playBook];
    [self.player play];
}
/** 上一曲 */
- (IBAction)upBook:(UIButton *)sender {
     i = 0;
    [self runTimer];
    self.playBtn.selected = NO;
    if (_currentPlay == 0) {
        _currentPlay = _albumsArr.count - 1;
    }else if (_currentPlay < _albumsArr.count) {
        _currentPlay -= 1;
    }
    [self playBook];
    [self.player play];
}

- (void)playBook{
/** 播放地址 */
    NSMutableArray *arr = [NSMutableArray new];
    for (int i = 0; i < _albumsArr.count; i++) {
        LectureAlbumsTracksListModel *model = _albumsArr[i];
        [arr addObject:model.playUrl64];
    }
    NSArray *tracksArr = [arr copy];
    self.player = [AVPlayer playerWithURL:[NSURL URLWithString:tracksArr[_currentPlay]]];
   
/** 设置标题 */
    NSMutableArray *titleArray = [NSMutableArray new];
    for (int i = 0; i < _albumsArr.count; i++) {
        LectureAlbumsTracksListModel *model = _albumsArr[i];
        [titleArray addObject:model.title];
    }
    NSArray *titleArr = [titleArray copy];
    self.titleLb.text = titleArr[_currentPlay];
/** 设置图片 */
    NSMutableArray *imageViewArray = [NSMutableArray new];
    for (int i = 0; i < _albumsArr.count; i++) {
        LectureAlbumsTracksListModel *model = _albumsArr[i];
/** 有些model.coverLarge 为空 防止数组加nil会崩，给个没有实际意义的值 */
        if (model.coverLarge == nil) {
            [imageViewArray addObject:@"..."];
        }else{
            [imageViewArray addObject:model.coverLarge];
        }
    }
    NSArray *coverArr = [imageViewArray copy];
    [self.imageView setImageWithURL:[NSURL URLWithString:coverArr[_currentPlay]]];
    
}
- (IBAction)Umeng:(id)sender {
    NSMutableArray *imageViewArray = [NSMutableArray new];
    for (int i = 0; i < _albumsArr.count; i++) {
        LectureAlbumsTracksListModel *model = _albumsArr[i];
        /** 有些model.coverLarge 为空 防止数组加nil会崩，给个没有实际意义的值 */
        if (model.coverLarge == nil) {
            [imageViewArray addObject:@"..."];
        }else{
            [imageViewArray addObject:model.coverLarge];
        }
    }
    NSArray *coverArr = [imageViewArray copy];
    [[UMSocialData defaultData].urlResource setResourceType:UMSocialUrlResourceTypeImage url: coverArr[_currentPlay]];
            [UMSocialSnsService presentSnsIconSheetView:self
                                                 appKey:@"564694c5e0f55a86820079e9"
                                              shareText:@"分享百家讲坛"
                                             shareImage:nil
                                        shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToWechatSession,UMShareToQQ,UMShareToQzone,nil]
                                               delegate:nil];
}

-(void)didFinishGetUMSocialDataInViewController:(UMSocialResponseEntity *)response
{
    //根据`responseCode`得到发送结果,如果分享成功
    if(response.responseCode == UMSResponseCodeSuccess)
    {
        //得到分享到的微博平台名
        NSLog(@"share to sns name is %@",[[response.data allKeys] objectAtIndex:0]);
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
