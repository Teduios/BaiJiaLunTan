//
//  MeViewController.m
//  BaseProject
//
//  Created by apple-jd01 on 15/11/21.
//  Copyright © 2015年 guaiguai. All rights reserved.
//

#import "MeViewController.h"
#import "UMSocial.h"
@interface MeViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *iconIV;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;

@end

@implementation MeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}
- (IBAction)login:(id)sender {
    
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina];
    
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        
        //          获取微博用户名、uid、token等
        
        if (response.responseCode == UMSResponseCodeSuccess) {
            
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToSina];
            
            NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
            [self.iconIV setImageWithURL:[NSURL URLWithString:snsAccount.iconURL]];
            [self.loginBtn setTitle:snsAccount.userName forState:UIControlStateNormal];
        }});
    //获取accestoken以及新浪用户信息，得到的数据在回调Block对象形参respone的data属性
    [[UMSocialDataService defaultDataService] requestSnsInformation:UMShareToSina  completion:^(UMSocialResponseEntity *response){
        NSLog(@"SnsInformation is %@",response.data);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end
