//
//  LectureBookCell.h
//  BaseProject
//
//  Created by apple-jd01 on 15/11/9.
//  Copyright © 2015年 guaiguai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LectureBookCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageIV;
@property (weak, nonatomic) IBOutlet UILabel *nameLb;

@end
